<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
			ul{
	list-style: none;
	text-decoration: none; 
	margin: 0px;
	background-color: #A7D3B5;
} 
ul li {
	display: inline-block;
	padding: 0px;
	margin-bottom: 20px;


}
ul li a{
 	text-decoration: none;
 	color: #fff;
 	padding:  10px 30px;
 	border: 1px solid #fff; 
 	transition: 0.20s ease;
}
ul li a:hover{
	color: #27B8B8;
	}
.gallery{
	width: 100px;
	height: 100px;
	margin-top: 20px;
	margin-bottom: 0px;
	margin-right: 700px;
}
footer{
	background-color: #A7D3B5;
	font-size: 40px;
	color: #fff ;
	}
	h1{
		text-align: center;
	}
	.gallery1{
		display: inline-block;
		width: 350px;
		height: 400px;
		margin-left: 70px;
		}
		.gallery1 img{
	width: 230px;
	padding: 5px;
	filter: grayscale(100%);
	transition: 1s;
	border-radius: 20px;
}
.gallery1 img:hover{
filter: grayscale(0);
transform: scale(1.1);
}
form{
	text-align: left;
	color: white;
	margin-left: 70px;
}
.info{
	font-size: 25px;
	margin-left: 20px;
	color: white;
	background-color: blue;
}


	</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="home"><i class="fa fa-home"></i>&nbsp;HOME</a></li>
			<li><a href="about"><i class="fa fa-user"></i>&nbsp;ABOUT</a></li>
			<li><a href="contact"><i class="fa fa-phone"></i>&nbsp;CONTACT</a></li>

		</ul>
	</div>
	<div>
		 <h1>My Portfolio</h1>
	</div>
	<table>
		<tr>
		<th></th>
		<th>
			
			
		</th>
	</tr>

	<tr>
		<td><img src="images/1.jpg"  class="gallery1"></td>
		<td class="info">
			<label class="info">Name:</label><br>
			<label class="info">Age:</label>21 yrs/old<br>
			<label class="info">Year&Course:</label>BS-IT 3 Block 3<br>
			<label class="info">Address:</label><br>
			<label class="info">Motto: </label>
		</td>
	</tr>
	</table>
		
	<center>
	<div>
		<footer>despo</footer>
	</div>
	</center>

</body>
</html>